# Implementation handoff

Project  revision 5. Route: portal.

This is an ordered handoff, not an executable deployment or proof of acceptance. Obtain exact-target authorization outside this browser before runtime operations. Resolve credentials at runtime; never put secrets in these files.

## 1. Azure foundation and independent management
Prerequisites: None
Reachability, Azure resource identities, RBAC and service readiness evidence.

## 2. AD preparation
Prerequisites: foundation
Selected identity preparation and access accepted by owner.

## 3. Independent workstation and node preparation
Prerequisites: foundation, identity
Pinned media, static IPs, firmware, Arc registration and readiness.

## 4. Selected cluster deployment route
Prerequisites: bootstrap
Validation and deployment reach terminal success; verify cluster health.

## 5. Qualified S2D/SAN/CSV/storage path operations
Prerequisites: cluster
Preserve existing-data LUNs; verify stable disk identities, source budgets, CSV and path mappings.

## 6. Confirm Arc SDN support, DNS, access and maintenance
Prerequisites: cluster
Release/storage/intents supported; reserved DNS and one-way enablement reviewed.

## 7. Arc Network Controller enablement or existing-state verification
Prerequisites: sdn-prerequisites
Verify terminal action-plan result and healthy NC cluster service.

## 8. Logical networks and qualified NSG attachments
Prerequisites: sdn-enable
Verify intended allow and deny traffic; no AKS NSG attachment.

## 9. Workload placement and migration
Prerequisites: storage, sdn-policy
Capacity, placement, backup and traffic acceptance.

## 10. Operations, recovery and bootstrap exit
Prerequisites: workloads
Restore test, support ownership, permanent management and temporary access disposition.

## Toolkit hierarchy review

| Field | Value |
| --- | --- |
| Toolkit requested | false |
| Source commit | 2af2f2a0698bb178e95c9fe5579d955770cb9d60 |
| Scenario | s2d_ad |
| Qualification | design-only |
| Schema assertions | Not evaluated |
| Registry assertions | Not evaluated |
| Native reader | Blocked before input read; runtime unqualified |
| Source finding | The unmodified pinned reader exits before reading input: SupportsShouldProcess and an explicit WhatIf switch declare the same parameter twice. |
| Source finding | The reader expects root accounts, cluster_nodes and cluster_arm_deployment and flat networking.network_intents. Schema v4 requires identity.accounts, compute.cluster_nodes, compute.cluster_arm_deployment and networking.onprem.network_intents. Root legacy aliases are forbidden by the schema. |
| Source finding | The reader emits the AD parameter shape for LocalIdentity, forces a new deployment vault and cloud witness, and constructs credential references using fixed secret names rather than preserving the selected source vault/version. |
| Source finding | Single-item PowerShell output can lose array shape; explicit zero retention values can become defaults; per-node storage addresses and several SBE/custom-location inputs are discarded. |
| Source finding | The registry and hand-maintained schema disagree on account/ARM aliases, configurationMode and networking enums. Their open extension properties are not proof that a consumer reads those fields. |
| Source finding | The schema limits nodes to 16 and has no declared hybrid scenario. SAN-only 17–64 nodes and hybrid require a separately qualified consumer. |
| Source finding | The registry description of validate_only as non-deploying is unsafe for the pinned Microsoft templates: Validate creates or updates prerequisite Azure resources. |
| Unmapped stage / contract | Independent management and bootstrap consumers |
| Unmapped stage / contract | SAN arrays, fabrics, LUN presentations and multipath I/O |
| Unmapped stage / contract | Explicit CSV creation, resizing and Azure storage-path resources |
| Unmapped stage / contract | Arc SDN enablement, logical networks and policy |
| Unmapped stage / contract | Workload placement, licensing, operations and recovery |
| Unmapped stage / contract | Identity-specific local DNS and complete ARM parameter round trip |
| Unmapped stage / contract | Resource lifecycle, permission and runtime-evidence enforcement in the pinned reader |
| Unmapped stage / contract | Node memory units and exact BIOS-versus-firmware observations; source GB is not silently treated as GiB |
| Unmapped stage / contract | Deployment subscription/resource-group scope beyond Arc IDs; bootstrap subscription is not assumed to be the cluster subscription |
| Unmapped stage / contract | Scenario selection stays in the review; infrastructure_scenarios defines a registry, not a selected scenario field |
| Local parameter converter | 0.1.0; contract-tested |
| Conversion inputs | Blocked or not requested |
| Conversion evidence | 26 native Win32NT cases; PowerShell 7.6.6 |
| Consumer SHA-256 | 0bd407249a8adce7badf8608379d5d7a4fce3c8cc3e4b2a8f9ae12e3ce037e01 |
| Scope | Converts local files only. Native reference fixtures do not authorize or qualify Azure deployment. |
| Conversion correction | Toolkit conversion was not selected. |
| Conversion correction | Canonical Toolkit schema assertions must pass. |

## PowerShell and DSC

| Field | Value |
| --- | --- |
| PowerShell version | 7.4.6 |
| PowerShell stage | Local canonical Toolkit to ARM parameter conversion |
| PowerShell qualification | contract-tested |
| DSC selection | none |
| DSC version |  |
| DSC boundary |  |
| DSC qualification | No DSC stage selected. |

## Ansible stage

| Field | Value |
| --- | --- |
| Ansible requested | false |
| Named stage | Named Terraform cluster ARM handoff; local package and provider validation |
| Core | 2.21.4 |
| Core source | 997ad6b3491920e355c69eb35614097be9759dca |
| Controller Python | 3.13 |
| Controller record | Not selected |
| Qualification | design-only |
| Runtime qualified | false |
| Draft available | false |
| Boundary | Ansible runs on an external Linux controller. The current consumer permits local validation only; plan/apply are blocked by unresolved deployment qualification, even with an operator authorization file. |
| Separate unqualified stage | Physical host imaging, firmware, BMC and Arc registration |
| Separate unqualified stage | Directory or local-identity preparation |
| Separate unqualified stage | Management service deployment and bootstrap exit |
| Separate unqualified stage | SAN/S2D CSV and Azure storage-path operations |
| Separate unqualified stage | Arc SDN enablement and policy operations |
| Separate unqualified stage | Workloads, backup, restore and terminal acceptance |

## Terraform orchestration

| Field | Value |
| --- | --- |
| Terraform route selected | false |
| Named wrapper | azurelocal-terraform-arm-wrapper |
| Declared stage | Cluster ARM template submission only |
| Wrapper qualification | contract-tested |
| Deployment qualification | design-only |
| Deployment authorized | false |
| Runtime qualified | false |
| Terraform CLI | 1.15.6 |
| Provider | registry.terraform.io/hashicorp/azurerm 5.5.0 |
| Provider source | dd0632e8e90a761ea68afe3689d206310d8fac5d |
| Disabled draft available | false |
| Secret resolution | Existing source Key Vault references pass unchanged through parameters_content to ARM. No browser or Terraform data-source secret retrieval. |
| Contract boundary | Wrapper syntax, actual provider schema and synthetic mock plans are contract tests. The underlying Azure Local deployment and complete orchestration remain unqualified. Exported deployment_authorized is always false. |
| Limitation | ARM source best-practice findings and nested provider/API qualification remain open. |
| Limitation | No native Terraform implementation of physical host, SAN/CSV, Arc SDN or management guest stages is implied. |
| Limitation | Validate and Deploy are Azure Local template values; both submit Azure writes. Terraform deployment_mode is fixed Incremental. |
| Limitation | The resource group must already exist. No resource group, provider registration, remote state backend or credential is provisioned by this wrapper. |
| Limitation | prevent_destroy and disabled nested deletion do not prevent nested resource updates on apply or changes made after removing the wrapper. |
| Limitation | Key Vault references are passed to ARM; Terraform does not resolve these credentials. Protect plan/state files and never enable request/response debug logging for deployments. |
| Limitation | Contract tests use provider schema validation and mock-provider plans only. No target environment has been qualified. |

## ARM mapping and resource effects

| Field | Value |
| --- | --- |
| ARM route requested | false |
| Identity template | ad |
| Consumer commit | b56eb9051390299afe2d913bf2d10861fef279fd |
| Template SHA-256 | a95bf9a734cc7433f171a31685193ea053941b24f33111bddc9552ce20195f58 |
| Qualification | design-only |
| Native runtime qualified | false |
| Reference toolkit | ARM-TTK 0.27; 0ec9a41a4503e970a0ec8efb0cd08415cc172175 |
| Reference toolkit result | parameter-file-checks-passed; source-findings-open |
| API contract | 2025-09-15-preview; Full deploymentSettings body, pure variable expressions and top-level resource conditions tested; nested resource/provider and native deployment qualification remain open |
| Mapping corrections | 0 |
| Evaluated deployment settings | Unavailable |
| Active top-level resource instances | Not evaluated |
| Resource effect / boundary | Both Validate and Deploy submit resource changes. Validate is not a read-only preflight. |
| Resource effect / boundary | The templates create or update the Azure Local cluster, edge devices, role assignments, credential secrets and witness storage resources. |
| Resource effect / boundary | The witness account and witness secret are unconditional. A preserved witness or a no-witness design needs a different qualified consumer. |
| Resource effect / boundary | Creating a new vault also declares diagnostic storage and diagnostic settings. The pinned new-vault resource sets enableSoftDelete=false; current service behavior requires review. |
| Resource effect / boundary | Existing deployment vaults still receive secrets and role assignments. Secret resolution requires an existing source vault enabled for template deployment and deployment-principal Microsoft.KeyVault/vaults/deploy/action access. |
| Resource effect / boundary | HVCI, DRTM and side-channel mitigation are fixed true in the pinned deployment settings. These fixed choices need reconciliation with the selected security design. |
| Resource effect / boundary | SAN attachment, explicit CSV/storage-path creation and post-cluster Arc SDN are separate handoffs; these templates do not implement the complete design. |

## Management and bootstrap prerequisites

| Field | Value |
| --- | --- |
| Qualification | Design prerequisites, manual owner handoffs and unverified observations. No execution authorization. |
| Wave 1: Independent bootstrap prerequisites | Owner: unassigned. Acceptance: Independent access, permissions and pinned tools accepted.. |
| Wave 2: Target cluster availability | Owner: unassigned. Acceptance: Terminal deployment and cluster health evidence required.. |
| Target cluster availability requires Independent bootstrap prerequisites | Prepare access and nodes before deployment |
| Blocked prerequisites | No graph cycle detected; other validation still applies |

## Declared stages and ownership

## Findings

- SDN prefix must contain 1–8 letters or digits. Use the prefix that will form the Network Controller DNS name.
- Project name is required. Enter the value or record the responsible prerequisite owner.
- Environment purpose is required. Enter the value or record the responsible prerequisite owner.
- Technical owner is required. Enter the value or record the responsible prerequisite owner.
- Exact OS build is required. Enter the value or record the responsible prerequisite owner.
- Azure region is required. Enter the value or record the responsible prerequisite owner.
- Tenant reference is required. Enter the value or record the responsible prerequisite owner.
- Subscription reference is required. Enter the value or record the responsible prerequisite owner.
- Resource group reference is required. Enter the value or record the responsible prerequisite owner.
- Azure Local instance name is required. Enter the value or record the responsible prerequisite owner.
- Forest/domain FQDN is required. Enter the value or record the responsible prerequisite owner.
- OU distinguished name is required. Enter the value or record the responsible prerequisite owner.
- DNS namespace is required. Enter the value or record the responsible prerequisite owner.
- DNS servers is required. Enter the value or record the responsible prerequisite owner.
- DNS record owner is required. Enter the value or record the responsible prerequisite owner.
- Time source is required. Enter the value or record the responsible prerequisite owner.
- Identity preparation owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- The entered solution/OS pair differs from the documented 2604 deployment pair. Review solution 12.2604.1003.1006 with OS 26100.32690, or supply exact servicing-release evidence. Existing observations are not changed.
- The 2604 known-issues review remains an external deployment prerequisite. Review current MOC remediation, management-tool versions and recovery restrictions; retain terminal evidence for the actual target.
- AD deployment account reference is missing. Enter the value or record the responsible prerequisite owner.
- Arc SDN requires a qualified 26100 build or later; the entered build is not qualified by this catalog. Enter the exact supported OS build and review newer build applicability.
- SDN owner is missing. Enter the value or record the responsible prerequisite owner.
- SDN maintenanceWindow is missing. Enter the value or record the responsible prerequisite owner.
- SDN permissionEvidence is missing. Enter the value or record the responsible prerequisite owner.
- SDN dnsOwner is missing. Enter the value or record the responsible prerequisite owner.
- One-way enablement and maintenance impact must be reviewed. Enter the value or record the responsible prerequisite owner.
- Static SDN requires a precreated NC DNS record. Enter the value or record the responsible prerequisite owner.
- Static NC DNS must resolve to the fifth address in the deployment infrastructure pool. Record the management pool and its reserved fifth IP.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- S2D CSV needs exactly one S2D pool and no SAN LUN. Correct its backing source mapping.
- S2D CSV needs exactly one S2D pool and no SAN LUN. Correct its backing source mapping.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete runnerHost and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete acceptanceOwner and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete reachability and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete proxyTrust and record who accepts it.
- Native Windows preparation requires an exact PowerShell 7 version. Pin the version used by the selected scripts and modules.
- Azure CLI requires an exact reviewed version. Record the tool version used by the deployment consumer.

## External evidence

| Field | Value |
| --- | --- |

## Recovery and reconciliation
Keep original deployment/activity IDs and terminal evidence. An operator-reported success does not authenticate a receipt. Compare observed values with the intended project revision, review differences, and create a new revision; do not overwrite design intent automatically.