# Azure portal deployment worksheet

Project  · revision 5 · release 2604.0.0

Qualification: documentation-mapped operator handoff; no live deployment qualification. The selected support findings still apply.
Source: https://learn.microsoft.com/en-us/azure/azure-local/deploy/deploy-via-portal?view=azloc-2604
Source revision for the common Portal flow: MicrosoftDocs/azure-stack-docs c320ca069a5e1f5137a0b6c6ff934c984ece08de; disaggregated flow additionally reviewed 2026-09-11.

## Selected Portal inputs
| Field | Value |
| --- | --- |
| Deployment Key Vault |  |
| Vault soft-delete retention (days) | 30 |
| Deployment volume configuration | unresolved |
| Storage creation or preservation handoff |  |
| AD-route node local administrator username |  |
| AD-route node local administrator password reference |  |
| Deployment custom location name |  |
| Network ATC assigns storage IPs | true |
 
## Prerequisites
Confirm the selected release, qualified hardware, Arc registration, deployment permissions and independent management. Reuse/extend designs require an approved change boundary before opening a new-cluster wizard.

| Field | Value |
| --- | --- |
| Project name |  |
| Customer |  |
| Environment purpose |  |
| Technical owner |  |
| Business owner |  |
| Approver |  |
| Target date |  |
| Environment starting state | new-deployment |
| Design scope | complete-platform |
| Preservation boundary and allowed changes |  |
| Customer tags |  |

| Field | Value |
| --- | --- |
| Azure Local release | 2604.0.0 |
| Exact OS build |  |
| Solution version |  |
| SBE version |  |
| Storage architecture | s2d |
| Cluster identity | ad |
| Cluster topology | standard |
| Cluster deployment route | portal |
| Delivery depth | design-only |
| Deployment intent | new |
| Host network pattern | converged |
| Storage connectivity | switched |
| Release and topology support review |  |

### Physical nodes: Preserved physical host
| Field | Value |
| --- | --- |
| Name | Preserved physical host |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 | 192.0.2.21 |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

### Physical nodes: Sizing node 2
| Field | Value |
| --- | --- |
| Name | Sizing node 2 |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 |  |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

### Physical nodes: Sizing node 3
| Field | Value |
| --- | --- |
| Name | Sizing node 3 |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 |  |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

### Physical nodes: Sizing node 4
| Field | Value |
| --- | --- |
| Name | Sizing node 4 |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 |  |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

## 1. Basics
Select subscription, resource group, instance, region, topology and Active Directory identity. Add the exact Arc machines, install extensions and wait for machine validation. Select the qualified S2D topology. Select a new or existing eligible Key Vault; an existing vault with private endpoints is unsupported for deployment.

| Field | Value |
| --- | --- |
| Azure cloud | AzureCloud |
| Azure region |  |
| Tenant reference |  |
| Subscription reference |  |
| Resource group reference |  |
| Azure Local instance name |  |
| Custom location reference |  |
| Resource bridge reference |  |
| Resource providers and registration evidence |  |
| RBAC assignees, roles and scopes |  |
| Egress endpoints and connectivity validation |  |
| Policy exemptions and ownership |  |
| Witness choice | cloud |
| Witness resource reference |  |
| Quorum and witness evidence |  |

## 2. Configuration
Choose New configuration or an explicitly reviewed Template spec. The Quickstart template option is unavailable in the documented Portal flow. This worksheet supplies values; it does not upload a template spec.

## 3. Networking
Select switched/switchless and the supported traffic grouping. Match exact physical adapter names, VLANs and reviewed overrides. Portal uses Network ATC storage IP assignment; custom storage IPs require ARM. Reserve the infrastructure pool separately from host addresses.

## 4. Management
Review custom location and witness. Enter the prepared domain FQDN, OU, deployment user and identical node-local administrator credentials resolved privately at runtime. The OU must not be the domain root.

| Field | Value |
| --- | --- |
| Forest/domain FQDN |  |
| OU distinguished name |  |
| Deployment account reference |  |
| Directory preparation and delegated permissions |  |
| DNS namespace |  |
| DNS servers |  |
| DNS record owner |  |
| Time source |  |
| Identity preparation owner |  |
| Preparation acceptance evidence |  |
| AD deployment account username |  |

## 5. Security
Review recommended or customized security settings, encryption/key recovery, credential protection, drift control, application control and telemetry. Record exceptions and owner approval.

| Field | Value |
| --- | --- |
| Security profile | recommended |
| Secure Boot readiness observed | false |
| TPM readiness observed | false |
| BitLocker selected | true |
| Key recovery reference |  |
| Administrator groups and access model |  |
| Firewall and remote access policy |  |
| Audit retention |  |
| Security exceptions and approval |  |
| Enforce security baseline drift control | true |
| Enable Credential Guard | true |
| Require SMB signing | true |
| Encrypt intra-cluster SMB | false |
| Encrypt OS volumes | true |
| Encrypt data volumes | true |
| Enforce application control | true |
| Enable streaming telemetry | true |
| EU telemetry location | false |
| Enable episodic diagnostics | true |

## 6. Advanced
The Portal automatic workload option creates thin volumes. To retain fixed or mixed explicit CSV layouts, select infrastructure volumes only and create the reviewed workload layout after deployment. KeepStorage applies only to an eligible single-machine existing pool and requires preservation review.

### S2D pools: Imported sizing pool
| Field | Value |
| --- | --- |
| Name | Imported sizing pool |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Repair reserve (bytes) | 15360000000000 |
| Metadata reserve (%) | 1 |
| Fault domains |  |
| Expected growth (%) | 0 |
| Performance target |  |
| Repair reserve basis | Imported Surveyor repair reserve, kept separate from infrastructure CSVs. One percent metadata is a sizing assumption; confirm against the selected release. |
| Repair reserve calculation | explicit |
| Other commitments outside listed CSVs (bytes) | 0 |
| Allocation accounting scope | planned-inventory |
| Observed whole-pool allocation (bytes) | 0 |
| Observed whole-pool usage (bytes) | 0 |
| Allocation observation timestamp |  |
| Allocation observation reference |  |
| Maximum source nominal overcommit ratio | 1 |
| Pool capacity alert threshold (%) | 70 |
| Capacity alert owner |  |

### CSVs: Workload CSV sizing
| Field | Value |
| --- | --- |
| Name | Workload CSV sizing |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| CSV role | workload |
| Backing source | s2d |
| S2D pool |  |
| SAN LUN |  |
| Desired size | 4 |
| Capacity unit | TB |
| Allocated capacity | 0 |
| Observed used capacity | 0 |
| CSV provisioning | fixed |
| Thin growth reserve (%) | 0 |
| Maximum nominal overcommit ratio | 0 |
| Thin capacity alert policy |  |
| S2D resiliency | three-way-mirror |
| Mirror tier share (%) | 0 |
| Filesystem | ReFS |
| Allocation unit (KiB) | 0 |
| CSV mount directory |  |
| Placement/performance policy |  |
| CSV allocation basis | unresolved |
| CSV observation timestamp |  |
| CSV observation reference |  |
| Parity capacity media | derive-from-pool |
| Allocated mirror tier capacity | 0 |
| Allocated parity tier capacity | 0 |
| Used mirror tier capacity | 0 |
| Used parity tier capacity | 0 |
| Mirror storage tier identity |  |
| Parity storage tier identity |  |
| Resiliency/tier layout qualification |  |
| Observed existing resiliency | unobserved |

### CSVs: Infrastructure volume sizing
| Field | Value |
| --- | --- |
| Name | Infrastructure volume sizing |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| CSV role | infrastructure |
| Backing source | s2d |
| S2D pool |  |
| SAN LUN |  |
| Desired size | 0.25 |
| Capacity unit | TB |
| Allocated capacity | 0 |
| Observed used capacity | 0 |
| CSV provisioning | fixed |
| Thin growth reserve (%) | 0 |
| Maximum nominal overcommit ratio | 0 |
| Thin capacity alert policy |  |
| S2D resiliency | three-way-mirror |
| Mirror tier share (%) | 0 |
| Filesystem | ReFS |
| Allocation unit (KiB) | 0 |
| CSV mount directory |  |
| Placement/performance policy |  |
| CSV allocation basis | unresolved |
| CSV observation timestamp |  |
| CSV observation reference |  |
| Parity capacity media | derive-from-pool |
| Allocated mirror tier capacity | 0 |
| Allocated parity tier capacity | 0 |
| Used mirror tier capacity | 0 |
| Used parity tier capacity | 0 |
| Mirror storage tier identity |  |
| Parity storage tier identity |  |
| Resiliency/tier layout qualification |  |
| Observed existing resiliency | unobserved |

## 7. Tags
Review project tags and customer ownership. Tags in this worksheet are user-supplied design values.

Tags: 
## 8. Validation
Run the actual Portal validation only against separately authorized targets. Resolve failures and retain deployment/activity IDs and terminal results. Configurator checks do not substitute for environment validation.

## 9. Review + create
Recheck target identities, preservation boundaries, cost and ownership before the authorized operator starts deployment. Wait for terminal completion, then verify resources and cluster health.

## Post-deployment and recovery
Verify Arc machines, Azure Local, resource bridge, custom location, infrastructure logical network, vault/witness and selected storage paths. Complete the separately gated Arc SDN prerequisites, enablement, terminal action-plan and traffic acceptance. A failed deployment is reviewed through the instance Deployments > Resume deployment workflow; retain the original activity and recovery context. Complete monitoring, restore tests and handover.

| Field | Value |
| --- | --- |
| Enable Azure Local SDN | true |
| Existing SDN state | none |
| Existing SDN owner |  |
| Reason for opting out |  |
| SDN prefix |  |
| SDN DNS mode | static |
| Network Controller DNS record |  |
| Reserved Network Controller IPv4 |  |
| SDN DNS owner |  |
| SDN permissions evidence |  |
| Enablement owner |  |
| Maintenance window |  |
| One-way enablement reviewed | false |
| Operator-supplied terminal action-plan evidence |  |
| Intended allow/deny traffic acceptance evidence |  |


## Required corrections

- SDN prefix must contain 1–8 letters or digits. Use the prefix that will form the Network Controller DNS name.
- Project name is required. Enter the value or record the responsible prerequisite owner.
- Environment purpose is required. Enter the value or record the responsible prerequisite owner.
- Technical owner is required. Enter the value or record the responsible prerequisite owner.
- Exact OS build is required. Enter the value or record the responsible prerequisite owner.
- Azure region is required. Enter the value or record the responsible prerequisite owner.
- Tenant reference is required. Enter the value or record the responsible prerequisite owner.
- Subscription reference is required. Enter the value or record the responsible prerequisite owner.
- Resource group reference is required. Enter the value or record the responsible prerequisite owner.
- Azure Local instance name is required. Enter the value or record the responsible prerequisite owner.
- Forest/domain FQDN is required. Enter the value or record the responsible prerequisite owner.
- OU distinguished name is required. Enter the value or record the responsible prerequisite owner.
- DNS namespace is required. Enter the value or record the responsible prerequisite owner.
- DNS servers is required. Enter the value or record the responsible prerequisite owner.
- DNS record owner is required. Enter the value or record the responsible prerequisite owner.
- Time source is required. Enter the value or record the responsible prerequisite owner.
- Identity preparation owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Site is required. Enter the value or record the responsible prerequisite owner.
- Rack/failure domain is required. Enter the value or record the responsible prerequisite owner.
- OEM is required. Enter the value or record the responsible prerequisite owner.
- Model is required. Enter the value or record the responsible prerequisite owner.
- Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- Responsible owner is required. Enter the value or record the responsible prerequisite owner.
- The entered solution/OS pair differs from the documented 2604 deployment pair. Review solution 12.2604.1003.1006 with OS 26100.32690, or supply exact servicing-release evidence. Existing observations are not changed.
- The 2604 known-issues review remains an external deployment prerequisite. Review current MOC remediation, management-tool versions and recovery restrictions; retain terminal evidence for the actual target.
- AD deployment account reference is missing. Enter the value or record the responsible prerequisite owner.
- Arc SDN requires a qualified 26100 build or later; the entered build is not qualified by this catalog. Enter the exact supported OS build and review newer build applicability.
- SDN owner is missing. Enter the value or record the responsible prerequisite owner.
- SDN maintenanceWindow is missing. Enter the value or record the responsible prerequisite owner.
- SDN permissionEvidence is missing. Enter the value or record the responsible prerequisite owner.
- SDN dnsOwner is missing. Enter the value or record the responsible prerequisite owner.
- One-way enablement and maintenance impact must be reviewed. Enter the value or record the responsible prerequisite owner.
- Static SDN requires a precreated NC DNS record. Enter the value or record the responsible prerequisite owner.
- Static NC DNS must resolve to the fifth address in the deployment infrastructure pool. Record the management pool and its reserved fifth IP.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner.
- Node firmware is missing. Enter the value or record the responsible prerequisite owner.
- Node sbe is missing. Enter the value or record the responsible prerequisite owner.
- Node readiness is missing. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner.
- S2D CSV needs exactly one S2D pool and no SAN LUN. Correct its backing source mapping.
- S2D CSV needs exactly one S2D pool and no SAN LUN. Correct its backing source mapping.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete runnerHost and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete acceptanceOwner and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete reachability and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete proxyTrust and record who accepts it.
- Native Windows preparation requires an exact PowerShell 7 version. Pin the version used by the selected scripts and modules.
- Azure CLI requires an exact reviewed version. Record the tool version used by the deployment consumer.