# Azure Local design

Configurator 0.1.0 · Schema 8 · Revision 5
Release: 2604.0.0. 

Design intent and operator observations only. No infrastructure was deployed or runtime-qualified by this application.

## Project context

| Field | Value |
| --- | --- |
| Project name |  |
| Customer |  |
| Environment purpose |  |
| Technical owner |  |
| Business owner |  |
| Approver |  |
| Target date |  |
| Environment starting state | new-deployment |
| Design scope | complete-platform |
| Preservation boundary and allowed changes |  |
| Customer tags |  |

## Architecture choices

| Field | Value |
| --- | --- |
| Azure Local release | 2604.0.0 |
| Exact OS build |  |
| Solution version |  |
| SBE version |  |
| Storage architecture | s2d |
| Cluster identity | ad |
| Cluster topology | standard |
| Cluster deployment route | portal |
| Delivery depth | design-only |
| Deployment intent | new |
| Host network pattern | converged |
| Storage connectivity | switched |
| Release and topology support review |  |

## Management boundary

| Field | Value |
| --- | --- |
| Management approach | reuse-existing |
| Service ownership and preservation |  |
| Management acceptance owner |  |

## Independent bootstrap

| Field | Value |
| --- | --- |
| Bootstrap approach | manual-operator |
| Repository URL (retained inactive) |  |
| Branch or immutable ref (retained inactive) |  |
| Runner pool (retained inactive) |  |
| Runner operating system | windows |
| PowerShell 7 version |  |
| Azure CLI version |  |
| Exact module versions |  |
| Authentication method (retained inactive) | federated |
| Runner credential reference (retained inactive) |  |
| RBAC scope (retained inactive) |  |
| Necessary permissions and reuse verification (retained inactive) |  |
| Consent owner (retained inactive) |  |
| Expiry and rotation owner (retained inactive) |  |
| Credential expiry date (retained inactive) |  |
| Management, BMC, DNS and package reachability |  |
| Proxy and trust configuration |  |
| Temporary access removal, final ownership and exit evidence |  |
| Deployment workstation or runner host |  |
| Bootstrap service identity (retained inactive) |  |
| Runner management component (retained inactive) |  |
| Artifact repository service (retained inactive) |  |
| Secret store service (retained inactive) |  |
| Bootstrap acceptance owner |  |
| Permission review timestamp (retained inactive) |  |
| Permission review state (retained inactive) | unreviewed |
| Federation issuer (retained inactive) |  |
| Federation subject (retained inactive) |  |
| Federation audience (retained inactive) |  |
| Authentication certificate (retained inactive) |  |

## Azure resource context

| Field | Value |
| --- | --- |
| Azure cloud | AzureCloud |
| Azure region |  |
| Tenant reference |  |
| Subscription reference |  |
| Resource group reference |  |
| Azure Local instance name |  |
| Custom location reference |  |
| Resource bridge reference |  |
| Resource providers and registration evidence |  |
| RBAC assignees, roles and scopes |  |
| Egress endpoints and connectivity validation |  |
| Policy exemptions and ownership |  |
| Witness choice | cloud |
| Witness resource reference |  |
| Quorum and witness evidence |  |

## Identity preparation

| Field | Value |
| --- | --- |
| Forest/domain FQDN |  |
| OU distinguished name |  |
| Deployment account reference |  |
| Directory preparation and delegated permissions |  |
| Local administrator username (retained inactive) |  |
| Local administrator credential reference (retained inactive) |  |
| Cluster-specific Key Vault reference (retained inactive) |  |
| Resource-provider permissions (retained inactive) |  |
| Vault uses a private endpoint (retained inactive) | false |
| Secret backup, recovery and vault reachability (retained inactive) |  |
| SSH readiness observed (retained inactive) | false |
| DNS namespace |  |
| DNS servers |  |
| DNS record owner |  |
| Time source |  |
| Identity preparation owner |  |
| Preparation acceptance evidence |  |
| AD deployment account username |  |

## Security baseline

| Field | Value |
| --- | --- |
| Security profile | recommended |
| Secure Boot readiness observed | false |
| TPM readiness observed | false |
| BitLocker selected | true |
| Key recovery reference |  |
| Administrator groups and access model |  |
| Firewall and remote access policy |  |
| Audit retention |  |
| Security exceptions and approval |  |
| Enforce security baseline drift control | true |
| Enable Credential Guard | true |
| Require SMB signing | true |
| Encrypt intra-cluster SMB | false |
| Encrypt OS volumes | true |
| Encrypt data volumes | true |
| Enforce application control | true |
| Enable streaming telemetry | true |
| EU telemetry location | false |
| Enable episodic diagnostics | true |

## Arc SDN intent

| Field | Value |
| --- | --- |
| Enable Azure Local SDN | true |
| Existing SDN state | none |
| Existing SDN owner |  |
| Reason for opting out |  |
| SDN prefix |  |
| SDN DNS mode | static |
| Network Controller DNS record |  |
| Reserved Network Controller IPv4 |  |
| SDN DNS owner |  |
| SDN permissions evidence |  |
| Enablement owner |  |
| Maintenance window |  |
| One-way enablement reviewed | false |
| Operator-supplied terminal action-plan evidence |  |
| Intended allow/deny traffic acceptance evidence |  |

## Compute and placement policy

| Field | Value |
| --- | --- |
| Compute failure/maintenance reserve nodes | 1 |
| vCPU per physical core | 4 |
| OS memory reserve per node (GiB) | 8 |
| OS vCPU reserve per node | 4 |
| Sizing assumptions and source units | Surveyor 2.8.0; memory GB interpreted as GiB, small storage GB as GiB, explicit TB as decimal. Hardware threads recorded separately. Source outputs remain imported estimates. |
| Migration sequencing and recovery |  |

## ARM deployment inputs (retained inactive branch)

| Field | Value |
| --- | --- |
| ARM deployment stage | Validate |
| Prior validation deployment ID and terminal evidence |  |
| Deployment infrastructure network |  |
| Deployment object prefix |  |
| Deployment Key Vault |  |
| Key Vault diagnostic storage account |  |
| Cloud witness storage account |  |
| Vault soft-delete retention (days) | 30 |
| Diagnostic log retention (days) | 30 |
| Deployment volume configuration | unresolved |
| Storage creation or preservation handoff |  |
| AD-route node local administrator username |  |
| AD-route node local administrator password reference |  |
| Azure Local resource provider object ID |  |
| Deployment custom location name |  |
| Network ATC assigns storage IPs | true |
| Local-identity DNS mode (retained inactive) | UseDnsServer |
| SBE family |  |
| SBE publisher |  |
| SBE manifest source |  |
| SBE manifest creation timestamp |  |
| Preview deployment API reviewed | false |
| Template resource changes and owner review |  |
| Template qualification and known issues |  |

## Toolkit hierarchy export

| Field | Value |
| --- | --- |
| Include Toolkit hierarchy review | false |
| Toolkit deployment site |  |
| Toolkit site code |  |
| Toolkit environment name |  |
| Toolkit environment type | unresolved |
| Toolkit Azure tags (JSON object) |  |
| Toolkit stage and preservation boundary |  |

## PowerShell and DSC handoff

| Field | Value |
| --- | --- |
| PowerShell toolchain | 7.4.6 |
| DSC selection | none |
| Exact requested DSC version |  |
| DSC stage, target and preservation boundary |  |

## Toolkit hierarchy review

| Field | Value |
| --- | --- |
| Toolkit requested | false |
| Source commit | 2af2f2a0698bb178e95c9fe5579d955770cb9d60 |
| Scenario | s2d_ad |
| Qualification | design-only |
| Schema assertions | Not evaluated |
| Registry assertions | Not evaluated |
| Native reader | Blocked before input read; runtime unqualified |
| Source finding | The unmodified pinned reader exits before reading input: SupportsShouldProcess and an explicit WhatIf switch declare the same parameter twice. |
| Source finding | The reader expects root accounts, cluster_nodes and cluster_arm_deployment and flat networking.network_intents. Schema v4 requires identity.accounts, compute.cluster_nodes, compute.cluster_arm_deployment and networking.onprem.network_intents. Root legacy aliases are forbidden by the schema. |
| Source finding | The reader emits the AD parameter shape for LocalIdentity, forces a new deployment vault and cloud witness, and constructs credential references using fixed secret names rather than preserving the selected source vault/version. |
| Source finding | Single-item PowerShell output can lose array shape; explicit zero retention values can become defaults; per-node storage addresses and several SBE/custom-location inputs are discarded. |
| Source finding | The registry and hand-maintained schema disagree on account/ARM aliases, configurationMode and networking enums. Their open extension properties are not proof that a consumer reads those fields. |
| Source finding | The schema limits nodes to 16 and has no declared hybrid scenario. SAN-only 17–64 nodes and hybrid require a separately qualified consumer. |
| Source finding | The registry description of validate_only as non-deploying is unsafe for the pinned Microsoft templates: Validate creates or updates prerequisite Azure resources. |
| Unmapped stage / contract | Independent management and bootstrap consumers |
| Unmapped stage / contract | SAN arrays, fabrics, LUN presentations and multipath I/O |
| Unmapped stage / contract | Explicit CSV creation, resizing and Azure storage-path resources |
| Unmapped stage / contract | Arc SDN enablement, logical networks and policy |
| Unmapped stage / contract | Workload placement, licensing, operations and recovery |
| Unmapped stage / contract | Identity-specific local DNS and complete ARM parameter round trip |
| Unmapped stage / contract | Resource lifecycle, permission and runtime-evidence enforcement in the pinned reader |
| Unmapped stage / contract | Node memory units and exact BIOS-versus-firmware observations; source GB is not silently treated as GiB |
| Unmapped stage / contract | Deployment subscription/resource-group scope beyond Arc IDs; bootstrap subscription is not assumed to be the cluster subscription |
| Unmapped stage / contract | Scenario selection stays in the review; infrastructure_scenarios defines a registry, not a selected scenario field |
| Local parameter converter | 0.1.0; contract-tested |
| Conversion inputs | Blocked or not requested |
| Conversion evidence | 26 native Win32NT cases; PowerShell 7.6.6 |
| Consumer SHA-256 | 0bd407249a8adce7badf8608379d5d7a4fce3c8cc3e4b2a8f9ae12e3ce037e01 |
| Scope | Converts local files only. Native reference fixtures do not authorize or qualify Azure deployment. |
| Conversion correction | Toolkit conversion was not selected. |
| Conversion correction | Canonical Toolkit schema assertions must pass. |

## PowerShell and DSC

| Field | Value |
| --- | --- |
| PowerShell version | 7.4.6 |
| PowerShell stage | Local canonical Toolkit to ARM parameter conversion |
| PowerShell qualification | contract-tested |
| DSC selection | none |
| DSC version |  |
| DSC boundary |  |
| DSC qualification | No DSC stage selected. |

## Ansible stage

| Field | Value |
| --- | --- |
| Ansible requested | false |
| Named stage | Named Terraform cluster ARM handoff; local package and provider validation |
| Core | 2.21.4 |
| Core source | 997ad6b3491920e355c69eb35614097be9759dca |
| Controller Python | 3.13 |
| Controller record | Not selected |
| Qualification | design-only |
| Runtime qualified | false |
| Draft available | false |
| Boundary | Ansible runs on an external Linux controller. The current consumer permits local validation only; plan/apply are blocked by unresolved deployment qualification, even with an operator authorization file. |
| Separate unqualified stage | Physical host imaging, firmware, BMC and Arc registration |
| Separate unqualified stage | Directory or local-identity preparation |
| Separate unqualified stage | Management service deployment and bootstrap exit |
| Separate unqualified stage | SAN/S2D CSV and Azure storage-path operations |
| Separate unqualified stage | Arc SDN enablement and policy operations |
| Separate unqualified stage | Workloads, backup, restore and terminal acceptance |

## Terraform orchestration

| Field | Value |
| --- | --- |
| Terraform route selected | false |
| Named wrapper | azurelocal-terraform-arm-wrapper |
| Declared stage | Cluster ARM template submission only |
| Wrapper qualification | contract-tested |
| Deployment qualification | design-only |
| Deployment authorized | false |
| Runtime qualified | false |
| Terraform CLI | 1.15.6 |
| Provider | registry.terraform.io/hashicorp/azurerm 5.5.0 |
| Provider source | dd0632e8e90a761ea68afe3689d206310d8fac5d |
| Disabled draft available | false |
| Secret resolution | Existing source Key Vault references pass unchanged through parameters_content to ARM. No browser or Terraform data-source secret retrieval. |
| Contract boundary | Wrapper syntax, actual provider schema and synthetic mock plans are contract tests. The underlying Azure Local deployment and complete orchestration remain unqualified. Exported deployment_authorized is always false. |
| Limitation | ARM source best-practice findings and nested provider/API qualification remain open. |
| Limitation | No native Terraform implementation of physical host, SAN/CSV, Arc SDN or management guest stages is implied. |
| Limitation | Validate and Deploy are Azure Local template values; both submit Azure writes. Terraform deployment_mode is fixed Incremental. |
| Limitation | The resource group must already exist. No resource group, provider registration, remote state backend or credential is provisioned by this wrapper. |
| Limitation | prevent_destroy and disabled nested deletion do not prevent nested resource updates on apply or changes made after removing the wrapper. |
| Limitation | Key Vault references are passed to ARM; Terraform does not resolve these credentials. Protect plan/state files and never enable request/response debug logging for deployments. |
| Limitation | Contract tests use provider schema validation and mock-provider plans only. No target environment has been qualified. |

## ARM mapping and resource effects

| Field | Value |
| --- | --- |
| ARM route requested | false |
| Identity template | ad |
| Consumer commit | b56eb9051390299afe2d913bf2d10861fef279fd |
| Template SHA-256 | a95bf9a734cc7433f171a31685193ea053941b24f33111bddc9552ce20195f58 |
| Qualification | design-only |
| Native runtime qualified | false |
| Reference toolkit | ARM-TTK 0.27; 0ec9a41a4503e970a0ec8efb0cd08415cc172175 |
| Reference toolkit result | parameter-file-checks-passed; source-findings-open |
| API contract | 2025-09-15-preview; Full deploymentSettings body, pure variable expressions and top-level resource conditions tested; nested resource/provider and native deployment qualification remain open |
| Mapping corrections | 0 |
| Evaluated deployment settings | Unavailable |
| Active top-level resource instances | Not evaluated |
| Resource effect / boundary | Both Validate and Deploy submit resource changes. Validate is not a read-only preflight. |
| Resource effect / boundary | The templates create or update the Azure Local cluster, edge devices, role assignments, credential secrets and witness storage resources. |
| Resource effect / boundary | The witness account and witness secret are unconditional. A preserved witness or a no-witness design needs a different qualified consumer. |
| Resource effect / boundary | Creating a new vault also declares diagnostic storage and diagnostic settings. The pinned new-vault resource sets enableSoftDelete=false; current service behavior requires review. |
| Resource effect / boundary | Existing deployment vaults still receive secrets and role assignments. Secret resolution requires an existing source vault enabled for template deployment and deployment-principal Microsoft.KeyVault/vaults/deploy/action access. |
| Resource effect / boundary | HVCI, DRTM and side-channel mitigation are fixed true in the pinned deployment settings. These fixed choices need reconciliation with the selected security design. |
| Resource effect / boundary | SAN attachment, explicit CSV/storage-path creation and post-cluster Arc SDN are separate handoffs; these templates do not implement the complete design. |

## Management and bootstrap prerequisites

| Field | Value |
| --- | --- |
| Qualification | Design prerequisites, manual owner handoffs and unverified observations. No execution authorization. |
| Wave 1: Independent bootstrap prerequisites | Owner: unassigned. Acceptance: Independent access, permissions and pinned tools accepted.. |
| Wave 2: Target cluster availability | Owner: unassigned. Acceptance: Terminal deployment and cluster health evidence required.. |
| Target cluster availability requires Independent bootstrap prerequisites | Prepare access and nodes before deployment |
| Blocked prerequisites | No graph cycle detected; other validation still applies |

## Commercial summary

| Field | Value |
| --- | --- |
| Basis | User-entered dated quotes only. Currencies and one-time/recurring costs remain separate; taxes, discounts, exchange rates and rights are not inferred. |
| Unpriced records | None |
| Unresolved entitlement records | None |

## Capacity assessment

- Imported sizing pool (s2d): Capacity 92160000000000 bytes; repair reserve 15360000000000; metadata 921600000000; listed commitments 0; outside commitments 0; total commitments 0; growth reserve 0; nominal potential 0; usage 0; headroom 75878400000000. Design inventory estimate; runtime unverified. 

| Field | Value |
| --- | --- |
| CSV surveyor-volume-d134c5a3656b7cd8339ec605 | Logical 4000000000000 bytes; footprint factor 3; committed 12000000000000; nominal 12000000000000; mirror logical 0; parity logical 0.  |
| CSV surveyor-infrastructure-1c2917487e74e5bde5d29d4d | Logical 250000000000 bytes; footprint factor 3; committed 750000000000; nominal 750000000000; mirror logical 0; parity logical 0.  |
| Placement Workload CSV sizing | Logical size 4000000000000 bytes; assigned demand including growth 0; logical headroom 4000000000000. This demand is not added again to source commitments. |
| Placement Infrastructure volume sizing | Logical size 250000000000 bytes; assigned demand including growth 0; logical headroom 250000000000. This demand is not added again to source commitments. |
| workloads: Business VMs | 1073741824000 logical bytes counted; requested 1073741824000; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: Reporting service | 1272730423296 logical bytes counted; requested 1272730423296; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: Desktop pool | 317827579904 logical bytes counted; requested 317827579904; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: Desktop pool profile storage | 0 logical bytes counted; requested 0; CSV unplaced; Independent logical demand including growth.  |
| workloads: Application cluster control plane | 644245094400 logical bytes counted; requested 644245094400; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: Application cluster workers | 2858993459200 logical bytes counted; requested 2858993459200; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: SOFS service | 6842730423296 logical bytes counted; requested 6842730423296; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: MABS service | 51214748364800 logical bytes counted; requested 51214748364800; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: Arc SQL MI (GP) | 500000000000 logical bytes counted; requested 500000000000; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| workloads: Measured VM | 141733920768 logical bytes counted; requested 141733920768; CSV unplaced; Independent logical demand including growth. Logical storage demand has no CSV placement. |
| Unplaced storage demand (bytes) | 64866751089664 |

| Field | Value |
| --- | --- |
| availableVCpu | 756 |
| availableMemoryGiB | 744 |
| demandVCpu | 91.5 |
| demandMemoryGiB | 417 |
| includedServiceVCpu | 16 |
| includedServiceMemoryGiB | 64 |
| aksWorkerVCpu | 32 |
| aksWorkerMemoryGiB | 128 |

## Validation findings

- **error / input** SDN prefix must contain 1–8 letters or digits. Use the prefix that will form the Network Controller DNS name. (sdn / prefix)
- **error / input** Project name is required. Enter the value or record the responsible prerequisite owner. (project / name)
- **error / input** Environment purpose is required. Enter the value or record the responsible prerequisite owner. (project / purpose)
- **error / input** Technical owner is required. Enter the value or record the responsible prerequisite owner. (project / technicalOwner)
- **error / input** Exact OS build is required. Enter the value or record the responsible prerequisite owner. (architecture / osBuild)
- **error / input** Azure region is required. Enter the value or record the responsible prerequisite owner. (azure / region)
- **error / input** Tenant reference is required. Enter the value or record the responsible prerequisite owner. (azure / tenant)
- **error / input** Subscription reference is required. Enter the value or record the responsible prerequisite owner. (azure / subscription)
- **error / input** Resource group reference is required. Enter the value or record the responsible prerequisite owner. (azure / resourceGroup)
- **error / input** Azure Local instance name is required. Enter the value or record the responsible prerequisite owner. (azure / clusterName)
- **error / input** Forest/domain FQDN is required. Enter the value or record the responsible prerequisite owner. (identity / domain)
- **error / input** OU distinguished name is required. Enter the value or record the responsible prerequisite owner. (identity / ou)
- **error / input** DNS namespace is required. Enter the value or record the responsible prerequisite owner. (identity / dnsNamespace)
- **error / input** DNS servers is required. Enter the value or record the responsible prerequisite owner. (identity / dnsServers)
- **error / input** DNS record owner is required. Enter the value or record the responsible prerequisite owner. (identity / dnsOwner)
- **error / input** Time source is required. Enter the value or record the responsible prerequisite owner. (identity / timeSource)
- **error / input** Identity preparation owner is required. Enter the value or record the responsible prerequisite owner. (identity / preparationOwner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (nodes / owner)
- **error / input** Site is required. Enter the value or record the responsible prerequisite owner. (nodes / site)
- **error / input** Rack/failure domain is required. Enter the value or record the responsible prerequisite owner. (nodes / rack)
- **error / input** OEM is required. Enter the value or record the responsible prerequisite owner. (nodes / oem)
- **error / input** Model is required. Enter the value or record the responsible prerequisite owner. (nodes / model)
- **error / input** Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner. (nodes / catalog)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (nodes / owner)
- **error / input** Site is required. Enter the value or record the responsible prerequisite owner. (nodes / site)
- **error / input** Rack/failure domain is required. Enter the value or record the responsible prerequisite owner. (nodes / rack)
- **error / input** OEM is required. Enter the value or record the responsible prerequisite owner. (nodes / oem)
- **error / input** Model is required. Enter the value or record the responsible prerequisite owner. (nodes / model)
- **error / input** Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner. (nodes / catalog)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (nodes / owner)
- **error / input** Site is required. Enter the value or record the responsible prerequisite owner. (nodes / site)
- **error / input** Rack/failure domain is required. Enter the value or record the responsible prerequisite owner. (nodes / rack)
- **error / input** OEM is required. Enter the value or record the responsible prerequisite owner. (nodes / oem)
- **error / input** Model is required. Enter the value or record the responsible prerequisite owner. (nodes / model)
- **error / input** Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner. (nodes / catalog)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (nodes / owner)
- **error / input** Site is required. Enter the value or record the responsible prerequisite owner. (nodes / site)
- **error / input** Rack/failure domain is required. Enter the value or record the responsible prerequisite owner. (nodes / rack)
- **error / input** OEM is required. Enter the value or record the responsible prerequisite owner. (nodes / oem)
- **error / input** Model is required. Enter the value or record the responsible prerequisite owner. (nodes / model)
- **error / input** Hardware catalog evidence is required. Enter the value or record the responsible prerequisite owner. (nodes / catalog)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (pools / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (devices / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (volumes / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (volumes / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **error / input** Responsible owner is required. Enter the value or record the responsible prerequisite owner. (workloads / owner)
- **review / support** The entered solution/OS pair differs from the documented 2604 deployment pair. Review solution 12.2604.1003.1006 with OS 26100.32690, or supply exact servicing-release evidence. Existing observations are not changed. (architecture / solutionVersion)
- **review / support** The 2604 known-issues review remains an external deployment prerequisite. Review current MOC remediation, management-tool versions and recovery restrictions; retain terminal evidence for the actual target. (architecture / supportEvidence)
- **error / input** AD deployment account reference is missing. Enter the value or record the responsible prerequisite owner. (identity / deploymentAccount)
- **error / support** Arc SDN requires a qualified 26100 build or later; the entered build is not qualified by this catalog. Enter the exact supported OS build and review newer build applicability. (architecture / osBuild)
- **error / input** SDN owner is missing. Enter the value or record the responsible prerequisite owner. (sdn / owner)
- **error / input** SDN maintenanceWindow is missing. Enter the value or record the responsible prerequisite owner. (sdn / maintenanceWindow)
- **error / input** SDN permissionEvidence is missing. Enter the value or record the responsible prerequisite owner. (sdn / permissionEvidence)
- **error / input** SDN dnsOwner is missing. Enter the value or record the responsible prerequisite owner. (sdn / dnsOwner)
- **error / input** One-way enablement and maintenance impact must be reviewed. Enter the value or record the responsible prerequisite owner. (sdn / irreversibleAcknowledged)
- **error / input** Static SDN requires a precreated NC DNS record. Enter the value or record the responsible prerequisite owner. (sdn / dnsRecord)
- **error / input** Static NC DNS must resolve to the fifth address in the deployment infrastructure pool. Record the management pool and its reserved fifth IP. (sdn / reservedIp)
- **error / input** Node firmware is missing. Enter the value or record the responsible prerequisite owner. (nodes / firmware)
- **error / input** Node sbe is missing. Enter the value or record the responsible prerequisite owner. (nodes / sbe)
- **error / input** Node readiness is missing. Enter the value or record the responsible prerequisite owner. (nodes / readiness)
- **error / input** A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner. (nodes / managementIp)
- **error / input** Node firmware is missing. Enter the value or record the responsible prerequisite owner. (nodes / firmware)
- **error / input** Node sbe is missing. Enter the value or record the responsible prerequisite owner. (nodes / sbe)
- **error / input** Node readiness is missing. Enter the value or record the responsible prerequisite owner. (nodes / readiness)
- **error / input** A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner. (nodes / managementIp)
- **error / input** Node firmware is missing. Enter the value or record the responsible prerequisite owner. (nodes / firmware)
- **error / input** Node sbe is missing. Enter the value or record the responsible prerequisite owner. (nodes / sbe)
- **error / input** Node readiness is missing. Enter the value or record the responsible prerequisite owner. (nodes / readiness)
- **error / input** A static node management IPv4 is required. Enter the value or record the responsible prerequisite owner. (nodes / managementIp)
- **error / input** Node firmware is missing. Enter the value or record the responsible prerequisite owner. (nodes / firmware)
- **error / input** Node sbe is missing. Enter the value or record the responsible prerequisite owner. (nodes / sbe)
- **error / input** Node readiness is missing. Enter the value or record the responsible prerequisite owner. (nodes / readiness)
- **error / input** Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner. (devices / eligible)
- **error / input** Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner. (devices / eligible)
- **error / input** Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner. (devices / eligible)
- **error / input** Capacity device eligibility is unverified. Enter the value or record the responsible prerequisite owner. (devices / eligible)
- **error / reference** S2D CSV needs exactly one S2D pool and no SAN LUN. Correct its backing source mapping. (volumes / pool)
- **error / reference** S2D CSV needs exactly one S2D pool and no SAN LUN. Correct its backing source mapping. (volumes / pool)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / capacity** Logical storage demand has no CSV placement. Review the backing CSV, linked resource and logical storage reservation. (workloads / volume)
- **error / input** Bootstrap needs an independent workstation/runner and access acceptance. Complete runnerHost and record who accepts it. (bootstrap / runnerHost)
- **error / input** Bootstrap needs an independent workstation/runner and access acceptance. Complete acceptanceOwner and record who accepts it. (bootstrap / acceptanceOwner)
- **error / input** Bootstrap needs an independent workstation/runner and access acceptance. Complete reachability and record who accepts it. (bootstrap / reachability)
- **error / input** Bootstrap needs an independent workstation/runner and access acceptance. Complete proxyTrust and record who accepts it. (bootstrap / proxyTrust)
- **error / qualification** Native Windows preparation requires an exact PowerShell 7 version. Pin the version used by the selected scripts and modules. (bootstrap / powershellVersion)
- **error / qualification** Azure CLI requires an exact reviewed version. Record the tool version used by the deployment consumer. (bootstrap / azureCliVersion)

## Sites and racks

## Management components

## Service dependencies

## Bootstrap tasks

## Azure resources

## Service identities

## Certificates and trust

## Physical nodes

### Preserved physical host
Stable ID: surveyor-node-5feceb66ffc86f38d952786c
| Field | Value |
| --- | --- |
| Name | Preserved physical host |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 | 192.0.2.21 |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

### Sizing node 2
Stable ID: surveyor-node-6b86b273ff34fce19d6b804e
| Field | Value |
| --- | --- |
| Name | Sizing node 2 |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 |  |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

### Sizing node 3
Stable ID: surveyor-node-d4735e3a265e16eee03f5971
| Field | Value |
| --- | --- |
| Name | Sizing node 3 |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 |  |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

### Sizing node 4
Stable ID: surveyor-node-4e07408562bedb8b60ce05c1
| Field | Value |
| --- | --- |
| Name | Sizing node 4 |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Site |  |
| Rack/failure domain |  |
| OEM |  |
| Model |  |
| Hardware catalog evidence |  |
| Serial/asset |  |
| CPU model |  |
| Sockets | 0 |
| Total physical cores | 32 |
| Hardware threads per physical core | 2 |
| Memory (GiB) | 256 |
| Firmware baseline |  |
| SBE version |  |
| BMC DNS name or IP |  |
| BMC credential reference |  |
| OS media |  |
| Observed OS build |  |
| Management IPv4 |  |
| Arc machine ID |  |
| Physical/Arc readiness evidence |  |
| Secure Boot observed | false |
| TPM observed | false |

## Media and artifacts

## Physical networks

## Network ATC intents

## Physical ports and adapters

## S2D pools

### Imported sizing pool
Stable ID: surveyor-pool-dc1d7684b83de6088d6edc14
| Field | Value |
| --- | --- |
| Name | Imported sizing pool |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Repair reserve (bytes) | 15360000000000 |
| Metadata reserve (%) | 1 |
| Fault domains |  |
| Expected growth (%) | 0 |
| Performance target |  |
| Repair reserve basis | Imported Surveyor repair reserve, kept separate from infrastructure CSVs. One percent metadata is a sizing assumption; confirm against the selected release. |
| Repair reserve calculation | explicit |
| Other commitments outside listed CSVs (bytes) | 0 |
| Allocation accounting scope | planned-inventory |
| Observed whole-pool allocation (bytes) | 0 |
| Observed whole-pool usage (bytes) | 0 |
| Allocation observation timestamp |  |
| Allocation observation reference |  |
| Maximum source nominal overcommit ratio | 1 |
| Pool capacity alert threshold (%) | 70 |
| Capacity alert owner |  |

## Local disks

### Sizing node 1 capacity drives
Stable ID: surveyor-device-capacity-5feceb66ffc86f38d952786c
| Field | Value |
| --- | --- |
| Name | Sizing node 1 capacity drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Preserved physical host [surveyor-node-5feceb66ffc86f38d952786c] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | capacity |
| Media | ssd |
| Stable device identity |  |
| Device capacity | 3.84 |
| Capacity unit | TB |
| Device count | 6 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

### Sizing node 1 cache drives
Stable ID: surveyor-device-cache-5feceb66ffc86f38d952786c
| Field | Value |
| --- | --- |
| Name | Sizing node 1 cache drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Preserved physical host [surveyor-node-5feceb66ffc86f38d952786c] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | cache |
| Media | nvme |
| Stable device identity |  |
| Device capacity | 1.6 |
| Capacity unit | TB |
| Device count | 2 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

### Sizing node 2 capacity drives
Stable ID: surveyor-device-capacity-6b86b273ff34fce19d6b804e
| Field | Value |
| --- | --- |
| Name | Sizing node 2 capacity drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Sizing node 2 [surveyor-node-6b86b273ff34fce19d6b804e] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | capacity |
| Media | ssd |
| Stable device identity |  |
| Device capacity | 3.84 |
| Capacity unit | TB |
| Device count | 6 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

### Sizing node 2 cache drives
Stable ID: surveyor-device-cache-6b86b273ff34fce19d6b804e
| Field | Value |
| --- | --- |
| Name | Sizing node 2 cache drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Sizing node 2 [surveyor-node-6b86b273ff34fce19d6b804e] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | cache |
| Media | nvme |
| Stable device identity |  |
| Device capacity | 1.6 |
| Capacity unit | TB |
| Device count | 2 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

### Sizing node 3 capacity drives
Stable ID: surveyor-device-capacity-d4735e3a265e16eee03f5971
| Field | Value |
| --- | --- |
| Name | Sizing node 3 capacity drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Sizing node 3 [surveyor-node-d4735e3a265e16eee03f5971] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | capacity |
| Media | ssd |
| Stable device identity |  |
| Device capacity | 3.84 |
| Capacity unit | TB |
| Device count | 6 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

### Sizing node 3 cache drives
Stable ID: surveyor-device-cache-d4735e3a265e16eee03f5971
| Field | Value |
| --- | --- |
| Name | Sizing node 3 cache drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Sizing node 3 [surveyor-node-d4735e3a265e16eee03f5971] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | cache |
| Media | nvme |
| Stable device identity |  |
| Device capacity | 1.6 |
| Capacity unit | TB |
| Device count | 2 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

### Sizing node 4 capacity drives
Stable ID: surveyor-device-capacity-4e07408562bedb8b60ce05c1
| Field | Value |
| --- | --- |
| Name | Sizing node 4 capacity drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Sizing node 4 [surveyor-node-4e07408562bedb8b60ce05c1] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | capacity |
| Media | ssd |
| Stable device identity |  |
| Device capacity | 3.84 |
| Capacity unit | TB |
| Device count | 6 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

### Sizing node 4 cache drives
Stable ID: surveyor-device-cache-4e07408562bedb8b60ce05c1
| Field | Value |
| --- | --- |
| Name | Sizing node 4 cache drives |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Node | Sizing node 4 [surveyor-node-4e07408562bedb8b60ce05c1] |
| S2D pool | Imported sizing pool [surveyor-pool-dc1d7684b83de6088d6edc14] |
| Device role | cache |
| Media | nvme |
| Stable device identity |  |
| Device capacity | 1.6 |
| Capacity unit | TB |
| Device count | 2 |
| Endurance rating |  |
| Eligibility verified | false |
| Drive firmware |  |

## SAN arrays (retained inactive branch)

## SAN fabrics (retained inactive branch)

## SAN initiators (retained inactive branch)

## SAN targets (retained inactive branch)

## SAN LUNs (retained inactive branch)

## Per-node SAN I/O paths (retained inactive branch)

## CSVs

### Workload CSV sizing
Stable ID: surveyor-volume-d134c5a3656b7cd8339ec605
| Field | Value |
| --- | --- |
| Name | Workload CSV sizing |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| CSV role | workload |
| Backing source | s2d |
| S2D pool |  |
| SAN LUN |  |
| Desired size | 4 |
| Capacity unit | TB |
| Allocated capacity | 0 |
| Observed used capacity | 0 |
| CSV provisioning | fixed |
| Thin growth reserve (%) | 0 |
| Maximum nominal overcommit ratio | 0 |
| Thin capacity alert policy |  |
| S2D resiliency | three-way-mirror |
| Mirror tier share (%) | 0 |
| Filesystem | ReFS |
| Allocation unit (KiB) | 0 |
| CSV mount directory |  |
| Placement/performance policy |  |
| CSV allocation basis | unresolved |
| CSV observation timestamp |  |
| CSV observation reference |  |
| Parity capacity media | derive-from-pool |
| Allocated mirror tier capacity | 0 |
| Allocated parity tier capacity | 0 |
| Used mirror tier capacity | 0 |
| Used parity tier capacity | 0 |
| Mirror storage tier identity |  |
| Parity storage tier identity |  |
| Resiliency/tier layout qualification |  |
| Observed existing resiliency | unobserved |

### Infrastructure volume sizing
Stable ID: surveyor-infrastructure-1c2917487e74e5bde5d29d4d
| Field | Value |
| --- | --- |
| Name | Infrastructure volume sizing |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| CSV role | infrastructure |
| Backing source | s2d |
| S2D pool |  |
| SAN LUN |  |
| Desired size | 0.25 |
| Capacity unit | TB |
| Allocated capacity | 0 |
| Observed used capacity | 0 |
| CSV provisioning | fixed |
| Thin growth reserve (%) | 0 |
| Maximum nominal overcommit ratio | 0 |
| Thin capacity alert policy |  |
| S2D resiliency | three-way-mirror |
| Mirror tier share (%) | 0 |
| Filesystem | ReFS |
| Allocation unit (KiB) | 0 |
| CSV mount directory |  |
| Placement/performance policy |  |
| CSV allocation basis | unresolved |
| CSV observation timestamp |  |
| CSV observation reference |  |
| Parity capacity media | derive-from-pool |
| Allocated mirror tier capacity | 0 |
| Allocated parity tier capacity | 0 |
| Used mirror tier capacity | 0 |
| Used parity tier capacity | 0 |
| Mirror storage tier identity |  |
| Parity storage tier identity |  |
| Resiliency/tier layout qualification |  |
| Observed existing resiliency | unobserved |

## Azure storage paths

## Workload logical networks

## Network security groups

## NSG rules

## Workloads

### Business VMs
Stable ID: surveyor-workload-vm-2d62b0035f348790d3b99c33
| Field | Value |
| --- | --- |
| Name | Business VMs |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | vm |
| Workload role | general |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 2 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 5 |
| vCPU per instance | 4 |
| Memory per instance (GiB) | 16 |
| Storage per instance (GiB) | 200 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target |  |
| Backup and recovery |  |
| Migration requirements |  |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### Reporting service
Stable ID: surveyor-workload-custom-f0a7f9a9e5bdcd9f40e33a47
| Field | Value |
| --- | --- |
| Name | Reporting service |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | vm |
| Workload role | general |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 2 |
| vCPU per instance | 4 |
| Memory per instance (GiB) | 16 |
| Storage per instance (GiB) | 592.6612873077393 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target | 100 Mbps sizing requirement |
| Backup and recovery |  |
| Migration requirements | Synthetic sizing fixture |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### Desktop pool
Stable ID: surveyor-workload-avd-4ec6ff55d62f5073eff873a8
| Field | Value |
| --- | --- |
| Name | Desktop pool |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | avd |
| Workload role | general |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 2 |
| vCPU per instance | 4 |
| Memory per instance (GiB) | 16 |
| Storage per instance (GiB) | 148 |
| Growth (%) | 0 |
| Guest OS/image | Windows multi-session sizing |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target | Imported 16 sizing users; 8 users per host; preset limited. |
| Backup and recovery |  |
| Migration requirements |  |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### Desktop pool profile storage
Stable ID: surveyor-workload-avd-profiles-4ec6ff55d62f5073eff873a8
| Field | Value |
| --- | --- |
| Name | Desktop pool profile storage |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | avd |
| Workload role | profile-storage |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 1 |
| vCPU per instance | 0 |
| Memory per instance (GiB) | 0 |
| Storage per instance (GiB) | 0 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target |  |
| Backup and recovery |  |
| Migration requirements | Profile demand is included in the separately imported SOFS backing service. Verify the source linkage and SOFS sizing before placement. |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### Application cluster control plane
Stable ID: surveyor-workload-aks-control-f7962793a1505af2b419591d
| Field | Value |
| --- | --- |
| Name | Application cluster control plane |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | aks |
| Workload role | aks-control-plane |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 3 |
| vCPU per instance | 4 |
| Memory per instance (GiB) | 16 |
| Storage per instance (GiB) | 200 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target |  |
| Backup and recovery |  |
| Migration requirements |  |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### Application cluster workers
Stable ID: surveyor-workload-aks-worker-f7962793a1505af2b419591d
| Field | Value |
| --- | --- |
| Name | Application cluster workers |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | aks |
| Workload role | aks-worker |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 4 |
| vCPU per instance | 8 |
| Memory per instance (GiB) | 32 |
| Storage per instance (GiB) | 665.6612873077393 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target |  |
| Backup and recovery |  |
| Migration requirements | Persistent volume requirement is distributed for aggregate sizing only. Confirm actual PVC placement. |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### SOFS service
Stable ID: surveyor-workload-sofs-c9ff0d856b07ac23b162c826
| Field | Value |
| --- | --- |
| Name | SOFS service |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | management |
| Workload role | sofs |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 2 |
| vCPU per instance | 4 |
| Memory per instance (GiB) | 16 |
| Storage per instance (GiB) | 3186.394657611847 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement | 2 guest VMs; shared storage layout. Internal three-way overhead already included; apply outer CSV resiliency separately. |
| IOPS/latency target |  |
| Backup and recovery |  |
| Migration requirements |  |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### MABS service
Stable ID: surveyor-workload-mabs-e0a7fa7d43f2bc3c9b847dc3
| Field | Value |
| --- | --- |
| Name | MABS service |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | management |
| Workload role | mabs |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 1 |
| vCPU per instance | 8 |
| Memory per instance (GiB) | 32 |
| Storage per instance (GiB) | 47697.451305389404 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target |  |
| Backup and recovery | Protected 10 TB; 14 retention days; internal two-way already included. |
| Migration requirements |  |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### Arc SQL MI (GP)
Stable ID: surveyor-workload-service-266ff5f617ec141c3c7e4fd2
| Field | Value |
| --- | --- |
| Name | Arc SQL MI (GP) |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | vm |
| Workload role | platform-service |
| Compute accounting | aks-worker-capacity |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 1 |
| vCPU per instance | 16 |
| Memory per instance (GiB) | 64 |
| Storage per instance (GiB) | 465.66128730773926 |
| Growth (%) | 0 |
| Guest OS/image |  |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target |  |
| Backup and recovery |  |
| Migration requirements | Source preset arc-sql-mi-gp. Defaults are source sizing assumptions, not a current support or licensing claim. |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

### Measured VM
Stable ID: surveyor-workload-inventory-17513e1e0a7db66cae63df56
| Field | Value |
| --- | --- |
| Name | Measured VM |
| Lifecycle | new |
| Responsible owner |  |
| Existing immutable identity |  |
| Operator-supplied evidence reference |  |
| Workload type | vm |
| Workload role | inventory |
| Compute accounting | own-demand |
| Workload CPU demand division ratio | 1 |
| Storage outside target cluster (GiB) | 0 |
| Instance count | 1 |
| vCPU per instance | 5.5 |
| Memory per instance (GiB) | 33 |
| Storage per instance (GiB) | 132 |
| Growth (%) | 0 |
| Guest OS/image | Windows Server |
| Image media |  |
| CSV placement |  |
| Azure storage path |  |
| Logical network |  |
| Reconciled management component |  |
| Placement boundary | target-cluster |
| VHDX allocation | fixed |
| Availability requirement |  |
| IOPS/latency target | {<br>  "cpuP95Pct": 50,<br>  "iopsP95": 100,<br>  "memoryP95Pct": 75,<br>  "observationDays": 14,<br>  "throughputMBpsP95": 20<br>}<br> |
| Backup and recovery |  |
| Migration requirements | Imported source source-cluster/source-host. measured-p95 and consumed; source power on; source reviewed=true. This is a sizing proposal; original allocations and observations remain in provenance. |
| Storage accounting | own-demand |
| Storage demand included in workload |  |
| Storage inclusion and placement basis |  |

## Licenses and costs

## Operations and acceptance

## Deployment and verification stages

## Per-node LUN presentation observations (retained inactive branch)

## Independent management hosting

## Management resource bindings

## Bootstrap access checks

## Bootstrap toolchain pins

## Temporary service exit plans

## ARM credential bindings (retained inactive branch)

## Deployment storage networks

## Per-node storage addresses

## Local-identity DNS zones (retained inactive branch)

## SBE partner properties

## SBE credential requirements

## Requested DSC resource contracts (retained inactive branch)

## Provenance

- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group hardware.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group drives.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group capacity.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group volumes.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group infrastructure.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group vms.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group custom.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group avd.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group aks.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group sofs.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group mabs.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group services.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group inventory.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.330Z; group source-results.
- azurelocal-surveyor:main 2.8.0, schema 1.0; SHA-256 35833a3cf607b5e3e35951899fd3076a5d3fa4f136e03ab1bfb8a908296b6e5d; imported 2026-09-12T00:52:08.992Z; group hardware.

## Support sources

- [sdn](https://learn.microsoft.com/en-us/azure/azure-local/concepts/sdn-overview?view=azloc-2604)
- [enableSdn](https://learn.microsoft.com/en-us/azure/azure-local/deploy/enable-sdn-integration?view=azloc-2604)
- [sanSdn](https://learn.microsoft.com/en-us/azure/azure-local/plan/network-patterns-overview-disaggregated?view=azloc-2604)
- [san](https://learn.microsoft.com/en-us/azure/azure-local/concepts/san-requirements?view=azloc-2604)
- [external](https://learn.microsoft.com/en-us/azure/azure-local/deploy/enable-external-storage?view=azloc-2604)
- [local](https://learn.microsoft.com/en-us/azure/azure-local/deploy/deployment-local-identity-with-key-vault?view=azloc-2604)
- [localOverview](https://learn.microsoft.com/en-us/azure/azure-local/deploy/deployment-local-identity-with-key-vault-overview?view=azloc-2604)
- [portal](https://learn.microsoft.com/en-us/azure/azure-local/deploy/deploy-via-portal?view=azloc-2604)
- [volumes](https://learn.microsoft.com/en-us/windows-server/storage/storage-spaces/plan-volumes)
- [knownIssues](https://learn.microsoft.com/en-us/azure/azure-local/known-issues?view=azloc-2604)
- [system](https://learn.microsoft.com/en-us/azure/azure-local/concepts/system-requirements-23h2?view=azloc-2604)
- [thin](https://learn.microsoft.com/en-us/azure/azure-local/manage/manage-thin-provisioning-23h2?view=azloc-2604)