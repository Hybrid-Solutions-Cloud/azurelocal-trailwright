# Azure portal deployment worksheet

Project Artifact acceptance · revision 2 · release 2604.0.0

Qualification: documentation-mapped operator handoff; no live deployment qualification. The selected support findings still apply.
Source: https://learn.microsoft.com/en-us/azure/azure-local/deploy/deploy-via-portal?view=azloc-2604
Source revision for the common Portal flow: MicrosoftDocs/azure-stack-docs c320ca069a5e1f5137a0b6c6ff934c984ece08de; disaggregated flow additionally reviewed 2026-09-11.

## Selected Portal inputs
| Field | Value |
| --- | --- |
| Deployment Key Vault |  |
| Vault soft-delete retention (days) | 30 |
| Deployment volume configuration | unresolved |
| Storage creation or preservation handoff |  |
| AD-route node local administrator username |  |
| AD-route node local administrator password reference |  |
| Deployment custom location name |  |
| Network ATC assigns storage IPs | true |
 
## Prerequisites
Confirm the selected release, qualified hardware, Arc registration, deployment permissions and independent management. Reuse/extend designs require an approved change boundary before opening a new-cluster wizard.

| Field | Value |
| --- | --- |
| Project name | Artifact acceptance |
| Customer |  |
| Environment purpose |  |
| Technical owner |  |
| Business owner |  |
| Approver |  |
| Target date |  |
| Environment starting state | new-deployment |
| Design scope | complete-platform |
| Preservation boundary and allowed changes |  |
| Customer tags |  |

| Field | Value |
| --- | --- |
| Azure Local release | 2604.0.0 |
| Exact OS build |  |
| Solution version |  |
| SBE version |  |
| Storage architecture | s2d |
| Cluster identity | ad |
| Cluster topology | standard |
| Cluster deployment route | portal |
| Delivery depth | design-only |
| Deployment intent | new |
| Host network pattern | converged |
| Storage connectivity | switched |
| Release and topology support review |  |

## 1. Basics
Select subscription, resource group, instance, region, topology and Active Directory identity. Add the exact Arc machines, install extensions and wait for machine validation. Select the qualified S2D topology. Select a new or existing eligible Key Vault; an existing vault with private endpoints is unsupported for deployment.

| Field | Value |
| --- | --- |
| Azure cloud | AzureCloud |
| Azure region |  |
| Tenant reference |  |
| Subscription reference |  |
| Resource group reference |  |
| Azure Local instance name |  |
| Custom location reference |  |
| Resource bridge reference |  |
| Resource providers and registration evidence |  |
| RBAC assignees, roles and scopes |  |
| Egress endpoints and connectivity validation |  |
| Policy exemptions and ownership |  |
| Witness choice | cloud |
| Witness resource reference |  |
| Quorum and witness evidence |  |

## 2. Configuration
Choose New configuration or an explicitly reviewed Template spec. The Quickstart template option is unavailable in the documented Portal flow. This worksheet supplies values; it does not upload a template spec.

## 3. Networking
Select switched/switchless and the supported traffic grouping. Match exact physical adapter names, VLANs and reviewed overrides. Portal uses Network ATC storage IP assignment; custom storage IPs require ARM. Reserve the infrastructure pool separately from host addresses.

## 4. Management
Review custom location and witness. Enter the prepared domain FQDN, OU, deployment user and identical node-local administrator credentials resolved privately at runtime. The OU must not be the domain root.

| Field | Value |
| --- | --- |
| Forest/domain FQDN |  |
| OU distinguished name |  |
| Deployment account reference |  |
| Directory preparation and delegated permissions |  |
| DNS namespace |  |
| DNS servers |  |
| DNS record owner |  |
| Time source |  |
| Identity preparation owner |  |
| Preparation acceptance evidence |  |
| AD deployment account username |  |

## 5. Security
Review recommended or customized security settings, encryption/key recovery, credential protection, drift control, application control and telemetry. Record exceptions and owner approval.

| Field | Value |
| --- | --- |
| Security profile | recommended |
| Secure Boot readiness observed | false |
| TPM readiness observed | false |
| BitLocker selected | true |
| Key recovery reference |  |
| Administrator groups and access model |  |
| Firewall and remote access policy |  |
| Audit retention |  |
| Security exceptions and approval |  |
| Enforce security baseline drift control | true |
| Enable Credential Guard | true |
| Require SMB signing | true |
| Encrypt intra-cluster SMB | false |
| Encrypt OS volumes | true |
| Encrypt data volumes | true |
| Enforce application control | true |
| Enable streaming telemetry | true |
| EU telemetry location | false |
| Enable episodic diagnostics | true |

## 6. Advanced
The Portal automatic workload option creates thin volumes. To retain fixed or mixed explicit CSV layouts, select infrastructure volumes only and create the reviewed workload layout after deployment. KeepStorage applies only to an eligible single-machine existing pool and requires preservation review.

## 7. Tags
Review project tags and customer ownership. Tags in this worksheet are user-supplied design values.

Tags: 
## 8. Validation
Run the actual Portal validation only against separately authorized targets. Resolve failures and retain deployment/activity IDs and terminal results. Configurator checks do not substitute for environment validation.

## 9. Review + create
Recheck target identities, preservation boundaries, cost and ownership before the authorized operator starts deployment. Wait for terminal completion, then verify resources and cluster health.

## Post-deployment and recovery
Verify Arc machines, Azure Local, resource bridge, custom location, infrastructure logical network, vault/witness and selected storage paths. Complete the separately gated Arc SDN prerequisites, enablement, terminal action-plan and traffic acceptance. A failed deployment is reviewed through the instance Deployments > Resume deployment workflow; retain the original activity and recovery context. Complete monitoring, restore tests and handover.

| Field | Value |
| --- | --- |
| Enable Azure Local SDN | true |
| Existing SDN state | none |
| Existing SDN owner |  |
| Reason for opting out |  |
| SDN prefix |  |
| SDN DNS mode | static |
| Network Controller DNS record |  |
| Reserved Network Controller IPv4 |  |
| SDN DNS owner |  |
| SDN permissions evidence |  |
| Enablement owner |  |
| Maintenance window |  |
| One-way enablement reviewed | false |
| Operator-supplied terminal action-plan evidence |  |
| Intended allow/deny traffic acceptance evidence |  |


## Required corrections

- SDN prefix must contain 1–8 letters or digits. Use the prefix that will form the Network Controller DNS name.
- Environment purpose is required. Enter the value or record the responsible prerequisite owner.
- Technical owner is required. Enter the value or record the responsible prerequisite owner.
- Exact OS build is required. Enter the value or record the responsible prerequisite owner.
- Azure region is required. Enter the value or record the responsible prerequisite owner.
- Tenant reference is required. Enter the value or record the responsible prerequisite owner.
- Subscription reference is required. Enter the value or record the responsible prerequisite owner.
- Resource group reference is required. Enter the value or record the responsible prerequisite owner.
- Azure Local instance name is required. Enter the value or record the responsible prerequisite owner.
- Forest/domain FQDN is required. Enter the value or record the responsible prerequisite owner.
- OU distinguished name is required. Enter the value or record the responsible prerequisite owner.
- DNS namespace is required. Enter the value or record the responsible prerequisite owner.
- DNS servers is required. Enter the value or record the responsible prerequisite owner.
- DNS record owner is required. Enter the value or record the responsible prerequisite owner.
- Time source is required. Enter the value or record the responsible prerequisite owner.
- Identity preparation owner is required. Enter the value or record the responsible prerequisite owner.
- The entered solution/OS pair differs from the documented 2604 deployment pair. Review solution 12.2604.1003.1006 with OS 26100.32690, or supply exact servicing-release evidence. Existing observations are not changed.
- The 2604 known-issues review remains an external deployment prerequisite. Review current MOC remediation, management-tool versions and recovery restrictions; retain terminal evidence for the actual target.
- Node count is outside the reference architecture range. Add the intended nodes; SAN-only permits up to 64 and S2D/hybrid up to 16 in the referenced 2604 matrix.
- AD deployment account reference is missing. Enter the value or record the responsible prerequisite owner.
- Arc SDN requires a qualified 26100 build or later; the entered build is not qualified by this catalog. Enter the exact supported OS build and review newer build applicability.
- SDN owner is missing. Enter the value or record the responsible prerequisite owner.
- SDN maintenanceWindow is missing. Enter the value or record the responsible prerequisite owner.
- SDN permissionEvidence is missing. Enter the value or record the responsible prerequisite owner.
- SDN dnsOwner is missing. Enter the value or record the responsible prerequisite owner.
- One-way enablement and maintenance impact must be reviewed. Enter the value or record the responsible prerequisite owner.
- Static SDN requires a precreated NC DNS record. Enter the value or record the responsible prerequisite owner.
- Static NC DNS must resolve to the fifth address in the deployment infrastructure pool. Record the management pool and its reserved fifth IP.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete runnerHost and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete acceptanceOwner and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete reachability and record who accepts it.
- Bootstrap needs an independent workstation/runner and access acceptance. Complete proxyTrust and record who accepts it.
- Native Windows preparation requires an exact PowerShell 7 version. Pin the version used by the selected scripts and modules.
- Azure CLI requires an exact reviewed version. Record the tool version used by the deployment consumer.